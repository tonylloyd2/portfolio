<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package knost
 */

namespace Knost\Knost;

$footer_class = '';
$knost_options = get_option('knost-options');
if (isset($knost_options['display_footer_bg_image'])) {
	$options = $knost_options['display_footer_bg_image'];
	if ($options == "yes") {
		if (isset($knost_options['footer_bg_image']['url'])) {
			$bgurl = $knost_options['footer_bg_image']['url'];
		}
	}
}
?>

<footer id="colophon" class="footer" <?php if (!empty($bgurl)) { ?> style="background-image: url(<?php echo esc_url($bgurl); ?> ) !important;" <?php } ?>>
	<?php
	get_template_part('template-parts/footer/widget');
	get_template_part('template-parts/footer/info');
	?>
	<!-- === back-to-top === -->
	<?php
		if (class_exists('ReduxFramework') && !empty($knost_options['back_to_top_text'])) {
			$top_text = $knost_options['back_to_top_text'];
		} else {
			$top_text = __('Top', 'knost');
		}
	?>

	<div id="back-to-top">
		<a class="top" id="top" href="#top">
		   <span class="text-top"><?php echo esc_html($top_text); ?></span>
		</a>
	</div>
	<!-- === back-to-top End === -->
</footer><!-- #colophon -->
</div><!-- #page -->
<?php wp_footer(); ?>
</body>

</html>