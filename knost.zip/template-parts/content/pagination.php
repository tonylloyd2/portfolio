<?php
/**
 * Template part for displaying a pagination
 *
 * @package knost
 */

namespace Knost\Knost;

knost()->knost_pagination();
