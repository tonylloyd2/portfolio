<?php
/**
 * Template part for displaying a post's comment and edit links
 *
 * @package knost
 */

namespace Knost\Knost;

?>
<div class="entry-actions">
	<?php knost()->knost_get_blog_readmore_link(get_the_permalink(), 'Read More'); ?>
</div><!-- .entry-actions -->
