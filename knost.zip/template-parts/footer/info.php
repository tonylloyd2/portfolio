<?php

/**
 * Template part for displaying the footer info
 *
 * @package knost
 */

namespace Knost\Knost;

if (class_exists('ReduxFramework')) {

	$knost_options = get_option('knost-options');
?>
	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<?php if (isset($knost_options['display_copyright']) && $knost_options['display_copyright'] == 'yes') {  ?>
					<div class="col-sm-12 m-0 text-<?php echo esc_attr($knost_options['footer_copyright_align']); ?>">
						<div class="pt-3 pb-3">
							<?php
							if (isset($knost_options['footer_copyright'])) {  ?>
								<span class="copyright"><?php echo html_entity_decode($knost_options['footer_copyright']); ?></span>
							<?php
							} else {	?>
								<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'knost')); ?>"> <?php printf(esc_html__('© 2021', 'knost'), 'knost'); ?><strong><?php printf(esc_html__(' knost ', 'knost'), 'knost'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'knost'), 'knost'); ?></a></span>
							<?php
							} ?>
						</div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div><!-- .site-info -->

<?php } else { ?>

	<div class="copyright-footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="pt-3 pb-3">
						<span class="copyright"><a target="_blank" href="<?php echo esc_url(__('https://iqonic.design/', 'knost')); ?>"> <?php printf(esc_html__('© 2021', 'knost'), 'knost'); ?><strong><?php printf(esc_html__(' knost ', 'knost'), 'knost'); ?></strong><?php printf(esc_html__('. All Rights Reserved.', 'knost'), 'knost'); ?></a></span>
					</div>
				</div>
			</div>
		</div>
	</div><!-- .site-info -->
<?php }
