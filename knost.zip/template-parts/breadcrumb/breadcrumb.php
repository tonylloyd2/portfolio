<?php

/**
 * Template part for displaying the Breadcrumb 
 *
 * @package knost
 */

namespace Knost\Knost;

if (is_front_page()) {
        if (is_home()) { ?>
            <div class="knost-breadcrumb-one text-center green-bg">
                <div class="container">
                    <div class="row flex-row-reverse">
                        <div class="col-sm-12">
                            <div class="heading-title white knost-breadcrumb-title">
                                <h1 class="title"><?php esc_html_e('Home', 'knost'); ?></h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php }
}
knost()->knost_inner_breadcrumb();
?>