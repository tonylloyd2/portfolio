<?php

/**
 * Knost\Knost\Dynamic_Style\Styles\Banner class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;

class Banner extends Component
{

    public function __construct()
    {
        add_action('wp_enqueue_scripts', array($this, 'knost_banner_dynamic_style'), 20);
        add_action('wp_enqueue_scripts', array($this, 'knost_opacity_color'), 20);
        add_action('wp_enqueue_scripts', array($this, 'knost_banner_hide'), 20);
    }

    public function knost_banner_dynamic_style()
    {
        $page_id = get_queried_object_id();
        $knost_options = get_option('knost-options');
        $dynamic_css = '';

        if (isset($knost_options['display_banner'])) {
            if ($knost_options['display_banner'] == 'no') {
                $dynamic_css .=
                    '.knost-breadcrumb-one { display: none !important; }
                    .content-area .site-main {padding : 0 !important; }';
            }
        }

        if (isset($knost_options['display_title'])) {

            if ($knost_options['display_title'] == 'no') {
                $dynamic_css .=
                    '.knost-breadcrumb-one .title { display: none !important; }';
            }
        }

        if (isset($knost_options['display_breadcumb'])) {

            if ($knost_options['display_breadcumb'] == 'no') {
                $dynamic_css .=
                    '.knost-breadcrumb-one .breadcrumb { display: none !important; }';
            }
        }

        if (isset($knost_options['bg_title_color'])) {

            if ($knost_options['bg_title_color'] == 'yes') {
                $dynamic = $knost_options['bg_title_color'];
                $dynamic_css .=
                    '.knost-breadcrumb-one .title { color: ' . $dynamic . ' !important; }';
            }
        }
        if (isset($knost_options['bg_type'])) {
            $opt = $knost_options['bg_type'];
            if ($opt == '1') {
                if (isset($knost_options['bg_color']) && !empty($knost_options['bg_color'])) {
                    $dynamic = $knost_options['bg_color'];
                    $dynamic_css .=
                        '.knost-breadcrumb-one { background: ' . $dynamic . ' !important; }';
                }
            }
            if ($opt == '2') {
                if (isset($knost_options['banner_image']['url'])) {
                    $dynamic = $knost_options['banner_image']['url'];
                    $dynamic_css .=
                        '.knost-breadcrumb-one { background-image: url(' . $dynamic . ') !important; }';
                }
            }
        }

        wp_add_inline_style('knost-global', $dynamic_css);
    }
    public function knost_opacity_color()
    {
        //Set Background Opacity Color
        $knost_options = get_option('knost-options');

        if (!empty($knost_options['bg_opacity']) && $knost_options['bg_opacity'] == "3") {
            $bg_opacity = $knost_options['opacity_color']['rgba'];
        }
        $dynamic_css = '';

        if (!empty($knost_options['bg_opacity']) && $knost_options['bg_opacity'] == "3") {
            if (!empty($bg_opacity) && $bg_opacity != '#ffffff') {
                $dynamic_css .= "
            .breadcrumb-video::before,.breadcrumb-bg::before, .breadcrumb-ui::before {
                background : $bg_opacity !important;
            }";
            }
        }
        wp_add_inline_style('knost-global', $dynamic_css);
    }

    public function knost_banner_hide()
    { 
        $knost_options = get_option('knost-options');
        $banner_hide = '';
        $pages = '';
        if(isset($knost_options['pages_select'])){
            $pages = $knost_options['pages_select'];
            foreach($pages as $data){

                $page = get_page_by_path( $data );
                if(isset($page)){
                    $banner_hide .= '.page-id-'.$page->ID.' .knost-breadcrumb-one { display: none !important; }';
                }
    
            }
        }

        wp_add_inline_style('knost-global', $banner_hide);
    }

}
