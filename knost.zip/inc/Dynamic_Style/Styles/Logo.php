<?php
/**
 * Knost\Knost\Dynamic_Style\Styles\Logo class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;

class Logo extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'knost_logo_options'), 20);
	}

	public function knost_logo_options(){
        $knost_options = get_option('knost-options');
        $logo_var = '';
        if(isset($knost_options['header_radio']) && $knost_options['header_radio'] == 1){
            if(isset($knost_options['header_color'])){
                $logo = $knost_options['header_color'];
                    $logo_var .= "
                    .navbar-light .navbar-brand {
                        color : $logo !important;
                    }"; 
            }  
        }          
            wp_add_inline_style( 'knost-global', $logo_var );
    }
}
