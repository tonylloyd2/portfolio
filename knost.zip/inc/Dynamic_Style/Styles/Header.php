<?php

/**
 * Knost\Knost\Dynamic_Style\Styles\Header class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;


class Header extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'knost_header_background_style'), 20);
		add_action('wp_enqueue_scripts', array($this, 'knost_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'knost_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'knost_burger_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'knost_action_btn_color_options'), 20);
	}

	public function knost_header_background_style()
	{
		$knost_option = get_option('knost-options');
		$dynamic_css = '';

		if (isset($knost_option['knost_header_background_type'])) {
			if (isset($knost_option['knost_header_background_type']) && $knost_option['knost_header_background_type'] != 'default') {
				$type = $knost_option['knost_header_background_type'];
				if ($type == 'color') {
					if (!empty($knost_option['knost_header_background_color'])) {
						$dynamic_css = 'header#default-header{
							background : ' . $knost_option['knost_header_background_color'] . '!important;
						}';
					}
				}
				if ($type == 'image') {
					if (!empty($knost_option['knost_header_background_image']['url'])) {
						$dynamic_css = 'header#default-header{
							background : url(' . $knost_option['knost_header_background_image']['url'] . ') !important;
						}';
					}
				}
				if ($type == 'transparent') {
					$dynamic_css = 'header#default-header{
						background : transparent !important;
					}';
				}
			}
		}
		wp_add_inline_style('knost-global', $dynamic_css);
	}

	public function knost_menu_color_options()
	{

		$knost_option =  get_option('knost-options');
		$inline_css = '';

		if (!empty($knost_option['menu_color']) && $knost_option['menu_color'] == "custom") {

			if (isset($knost_option['header_menu_color']) && !empty($knost_option['header_menu_color'])) {
				$inline_css .= '.sf-menu > li > a{
						color : ' . $knost_option['header_menu_color'] . '!important;
					}';
			}

			if (isset($knost_option['hover_menu_color']) && !empty($knost_option['hover_menu_color'])) {
				$inline_css .= '.sf-menu li:hover > a,.sf-menu li.current-menu-ancestor > a,.sf-menu  li.current-menu-item > a{
						color : ' . $knost_option['hover_menu_color'] . ' !important;
					}';
			}
		}



		wp_add_inline_style('knost-global', $inline_css);
	}

	public function knost_sub_menu_color_options()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';
		if (isset($knost_option['header_submenu_color_type']) && $knost_option['header_submenu_color_type'] == 'custom') {
			if (isset($knost_option['submenu_color']) && !empty($knost_option['submenu_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu a{
                   		color : ' . $knost_option['submenu_color'] . ' !important; }';
			}

			if (isset($knost_option['hover_submenu_color']) && !empty($knost_option['hover_submenu_color'])) {
				$inline_css .= '.sf-menu li.sfHover>a, .sf-menu li:hover>a,.sf-menu li.current-menu-ancestor>a, .sf-menu li.current-menu-item>a, .sf-menu ul>li.menu-item.current-menu-parent>a,.sf-menu ul li.current-menu-parent>a, .sf-menu ul li .sub-menu li.current-menu-item>a
                					{  color : ' . $knost_option['hover_submenu_color'] . ' !important;  }';
			}

			if (isset($knost_option['submenu_background_color']) && !empty($knost_option['submenu_background_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li{
                   background : ' . $knost_option['submenu_background_color'] . ' !important;  }';
			}

			if (isset($knost_option['hover_submenu_bg_color']) && !empty($knost_option['hover_submenu_bg_color'])) {
				$inline_css .= '.sf-menu ul.sub-menu li:hover,.sf-menu ul.sub-menu li.current-menu-item{
                   background : ' . $knost_option['hover_submenu_bg_color'] . ' !important;   }';
			}
		}
		wp_add_inline_style('knost-global', $inline_css);
	}

	public function knost_burger_menu_color_options()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';

		if (isset($knost_option['burger_menu_button_type']) && $knost_option['burger_menu_button_type'] == 'custom') {

			if (isset($knost_option['burger_menu_icon']) && !empty($knost_option['burger_menu_icon'])) {
				$inline_css .= ' .menu-btn .line {
                    background-color : ' . $knost_option['burger_menu_icon'] . ' !important;
                }';
			}

			if (isset($knost_option['burger_menu_popup_bg']) && !empty($knost_option['burger_menu_popup_bg'])) {
				$inline_css .= ' .knost-mobile-menu {
                    background : ' . $knost_option['burger_menu_popup_bg'] . ' !important;
                }';
			}
			

			if (isset($knost_option['burger_menu_color']) && !empty($knost_option['burger_menu_color'])) {
				$inline_css .= '.knost-mobile-menu .navbar-nav > li > a, .knost-mobile-menu .navbar-nav li > .toggledrop svg{ 
					color : ' . $knost_option['burger_menu_color'] . ' !important;
				}';
			}


			if (isset($knost_option['burger_hover_menu_color']) && !empty($knost_option['burger_hover_menu_color'])) {
				$inline_css .= '.knost-mobile-menu .navbar-nav li.current-menu-item > .toggledrop svg, .knost-mobile-menu .navbar-nav li.current-menu-item > a, .knost-mobile-menu .navbar-nav li .sub-menu li:hover > a, .knost-mobile-menu .navbar-nav li:hover > .toggledrop svg, .knost-mobile-menu .navbar-nav li:hover > a, .knost-mobile-menu ul > li.current-menu-ancestor > .toggledrop svg, .knost-mobile-menu ul > li.current-menu-ancestor > a, .knost-mobile-menu ul li .sub-menu li.current-menu-item > a, .knost-mobile-menu ul li .sub-menu li.menu-item.current-menu-ancestor > a{
			        color : ' . $knost_option['burger_hover_menu_color'] . ' !important;
				}';
			}

			if (isset($knost_option['burger_submenu_color']) && !empty($knost_option['burger_submenu_color'])) {
				$inline_css .= '.knost-mobile-menu .navbar-nav li .sub-menu li a , .knost-mobile-menu .navbar-nav li .sub-menu li svg{
			        color : ' . $knost_option['burger_submenu_color'] . ' !important;
				}';
			}
		}
		wp_add_inline_style('knost-global', $inline_css);
	}

	public function knost_action_btn_color_options()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';

		if (isset($knost_option['button_color']) && $knost_option['button_color'] == 'custom') {

			if (isset($knost_option['button_bg_color']) && !empty($knost_option['button_bg_color'])) {
				$inline_css .= '
            header .knost-shop-btn-holder  #btn-search svg,header .search_count #btn-search{
                color : ' . $knost_option['button_bg_color'] . ' !important;
            }';
			}
		}

		if (!empty($inline_css)) {
			wp_add_inline_style('knost-global', $inline_css);
		}
	}
}
