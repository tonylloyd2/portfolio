<?php

/**
 * Knost\Knost\Dynamic_Style\Styles\HeaderSticky class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;

class HeaderSticky extends Component
{
	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'knost_header_sticky_background_style'));
		add_action('wp_enqueue_scripts', array($this, 'knost_sticky_sub_menu_color_options'), 20);
		add_action('wp_enqueue_scripts', array($this, 'knost_sticky_menu_color_options'), 20);
	}

	public function knost_header_sticky_background_style()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';


		if (isset($knost_option['display_sticky_header'])) {
			if (isset($knost_option['sticky_header_bg']) && $knost_option['sticky_header_bg'] != 'default') {
				$type = $knost_option['sticky_header_bg'];

				if ($type == 'color') {
					if (!empty($knost_option['sticky_header_bg_color'])) {
						$inline_css .= 'header#default-header.menu-sticky{
							background : ' . $knost_option['sticky_header_bg_color'] . '!important;
						}';
					}
				}
				if ($type == 'image') {
					if (!empty($knost_option['sticky_header_bg_img']['url'])) {
						$inline_css .= 'header#default-header.menu-sticky{
							background : url(' . $knost_option['sticky_header_bg_img']['url'] . ') !important;
						}';
					}
				}
				if ($type == 'transparent') {
					$inline_css .= 'header#default-header.menu-sticky{
						background : transparent !important;
					}';
				}
			}
		}

		wp_add_inline_style('knost-global', $inline_css);
	}



	public function knost_sticky_menu_color_options()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';
		if (isset($knost_option['sticky_menu_color_type']) && $knost_option['sticky_menu_color_type'] == 'custom') {
			if (isset($knost_option['sticky_menu_color']) && !empty($knost_option['sticky_menu_color'])) {
				$inline_css .= 'header.header-down .sf-menu > li > a, header.header-up .sf-menu > li > a{
						color : ' . $knost_option['sticky_menu_color'] . '!important;
					}';
			}

			if (isset($knost_option['sticky_menu_hover_color']) && !empty($knost_option['sticky_menu_hover_color'])) {
				$inline_css .= 'header.header-down .sf-menu li:hover > a,header.header-down .sf-menu li.current-menu-ancestor > a,header.header-down .sf-menu  li.current-menu-item > a, header.header-up .sf-menu li:hover > a,header.header-up .sf-menu li.current-menu-ancestor > a,header.header-up .sf-menu  li.current-menu-item > a{
						color : ' . $knost_option['sticky_menu_hover_color'] . '!important;
					}';
			}
		}
		wp_add_inline_style('knost-global', $inline_css);
	}

	public function knost_sticky_sub_menu_color_options()
	{
		$knost_option = get_option('knost-options');
		$inline_css = '';

		if (isset($knost_option['sticky_header_submenu_color_type']) && $knost_option['sticky_header_submenu_color_type'] == 'custom') {
			if (isset($knost_option['sticky_knost_header_submenu_color']) && !empty($knost_option['sticky_knost_header_submenu_color'])) {
				$inline_css .= 'header.header-down .sf-menu ul.sub-menu a, header.header-up .sf-menu ul.sub-menu a{
                color : ' . $knost_option['sticky_knost_header_submenu_color'] . ' !important;
            }';
			}

			if (isset($knost_option['sticky_knost_header_submenu_hover_color']) && !empty($knost_option['sticky_knost_header_submenu_hover_color'])) {
				$inline_css .= 'header.header-down .sf-menu li.sfHover>a,header.header-down .sf-menu li:hover>a,header.header-down .sf-menu li.current-menu-ancestor>a,header.header-down .sf-menu li.current-menu-item>a,header.header-down .sf-menu ul>li.menu-item.current-menu-parent>a,header.header-down .sf-menu ul li.current-menu-parent>a,header.header-down .sf-menu ul li .sub-menu li.current-menu-item>a,
				header.header-up .sf-menu li.sfHover>a,header.header-up .sf-menu li:hover>a,header.header-up .sf-menu li.current-menu-ancestor>a,header.header-up .sf-menu li.current-menu-item>a,header.header-up .sf-menu ul>li.menu-item.current-menu-parent>a,header.header-up .sf-menu ul li.current-menu-parent>a,header.header-up .sf-menu ul li .sub-menu li.current-menu-item>a{
                color : ' . $knost_option['sticky_knost_header_submenu_hover_color'] . ' !important;
            }';
			}

			if (isset($knost_option['sticky_knost_header_submenu_background_color']) && !empty($knost_option['sticky_knost_header_submenu_background_color'])) {
				$inline_css .= 'header.header-up .sf-menu ul.sub-menu li, header.header-down .sf-menu ul.sub-menu li {
                background : ' . $knost_option['sticky_knost_header_submenu_background_color'] . ' !important;
            }';
			}

			if (isset($knost_option['sticky_header_submenu_background_hover_color']) && !empty($knost_option['sticky_header_submenu_background_hover_color'])) {
				$inline_css .= 'header.header-up .sf-menu ul.sub-menu li:hover,header.header-up .sf-menu ul.sub-menu li.current-menu-item ,header.header-up .sf-menu ul.sub-menu li:hover,header.header-up .sf-menu ul.sub-menu li.current-menu-item,
				header.header-down .sf-menu ul.sub-menu li:hover,header.header-down .sf-menu ul.sub-menu li.current-menu-item ,header.header-down .sf-menu ul.sub-menu li:hover,header.header-down .sf-menu ul.sub-menu li.current-menu-item{
                background : ' . $knost_option['sticky_header_submenu_background_hover_color'] . ' !important;
            }';
			}

		}
		wp_add_inline_style('knost-global', $inline_css);
	}
}
