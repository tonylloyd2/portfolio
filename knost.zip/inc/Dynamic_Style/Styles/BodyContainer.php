<?php
/**
 * Knost\Knost\Dynamic_Style\Styles\BodyContainer class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;

class BodyContainer extends Component
{

	public function __construct()
	{
		if (class_exists('ReduxFramework')) {
			add_action('wp_enqueue_scripts', array( $this,'knost_container_width'), 21);
		}
	}

	public function knost_container_width()
	{
		$knost_options = get_option('knost-options');

		$box_container_width = "";

		if (isset($knost_options['opt-slider-label']) && !empty($knost_options['opt-slider-label'])) {

			$container_width = $knost_options['opt-slider-label'];

			$box_container_width = "body.iq-container-width .container,
        							body.iq-container-width .elementor-section.elementor-section-boxed>
        							.elementor-container { max-width: " . $container_width . "px; } ";
		}


		wp_add_inline_style('knost-style',
			$box_container_width
		);
	}
}
