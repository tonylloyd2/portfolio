<?php

/**
 * Knost\Knost\Dynamic_Style\Styles\Footer class
 *
 * @package knost
 */

namespace Knost\Knost\Dynamic_Style\Styles;

use Knost\Knost\Dynamic_Style\Component;
use function add_action;

class Footer extends Component
{

	public function __construct()
	{
		add_action('wp_enqueue_scripts', array($this, 'knost_footer_dynamic_style'), 20);
	}

	public function knost_footer_dynamic_style()
	{

		$page_id = get_queried_object_id();
		$knost_options = get_option('knost-options');
		$footer_css = '';
		if (isset($knost_options['footer_top'])) {

			if ($knost_options['footer_top'] == 'no') {
				$footer_css = '.footer-top { 
					display : none !important;
				}';
			}
		}

		if (isset($knost_options['change_footer_color'])) {

			if (isset($knost_options['footer_bg_color']) && $knost_options['change_footer_color'] == '0') {
				$footer_bg_color = $knost_options['footer_bg_color'];
				$footer_css .= ".footer {
					background-color: $footer_bg_color !important;
				}";
			}
		}
	

		wp_add_inline_style('knost-global', $footer_css);
	}
}
