<?php

/**
 * Knost\Knost\Redux_Framework\Options\General class
 *
 * @package knost
 */

namespace Knost\Knost\Redux_Framework\Options;

use Redux;
use Knost\Knost\Redux_Framework\Component;

class Header extends Component
{

	public function __construct()
	{
		$this->set_widget_option();
	}
	public function get_hf_layout()
	{
		$args = array(
			'post_type'         => 'iqonic_hf_layout',
			'post_status'       => 'publish',
			'posts_per_page'    => -1,
			'meta_key'          => '_layout_meta_key',
			'meta_value'        => 'header',
		);
		global $post;
		$wp_query = get_posts($args);
		$iqonic_header_list = [];

		if ($wp_query) {
			foreach ($wp_query as $header) {
				$iqonic_header_list[$header->post_name] = $header->post_title;
			}
			return $iqonic_header_list;
		}
	}
	protected function set_widget_option()
	{
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Header', 'knost'),
			'id' => 'header',
			'icon' => 'el el-arrow-up',
			'customizer_width' => '500px',
		));

		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Header Layout', 'knost'),
			'id' => 'header_variation',
			'subsection' => true,
			'desc' => esc_html__('This section contains options for Menu .', 'knost'),
			'fields' => array(

				array(
					'id' => 'header_layout',
					'type' => 'button_set',
					'title' => esc_html__('Header Layout', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost'),
					),
					'default' => 'default'
				),

				array(
					'id' => 'header_container',
					'type' => 'button_set',
					'title' => esc_html__('Header container', 'knost'),
					'options' => array(
						'container-fluid' => esc_html__('full width', 'knost'),
						'container' => esc_html__('Container', 'knost'),
					),
					'default' => 'container-fluid'
				),


				array(
					'id' => 'header_postion',
					'type' => 'button_set',
					'title' => esc_html__('Header Position', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'over' => esc_html__('Over', 'knost'),
					),
					'default' => 'default'
				),


				// --------main header background options start----------//

				array(
					'id' => 'knost_header_background_type',
					'type' => 'button_set',
					'title' => esc_html__('Background', 'knost'),
					'subtitle' => esc_html__('Select the variation for header background', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'color' => esc_html__('Color', 'knost'),
						'image' => esc_html__('Image', 'knost'),
						'transparent' => esc_html__('Transparent', 'knost')
					),
					'default' => esc_html__('default', 'knost')
				),

				array(
					'id' => 'knost_header_background_color',
					'type' => 'color',
					'desc' => esc_html__('Set Background Color', 'knost'),
					'required' => array('knost_header_background_type', '=', 'color'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'knost_header_background_image',
					'type' => 'media',
					'url' => false,
					'desc' => esc_html__('Upload Image', 'knost'),
					'required' => array('knost_header_background_type', '=', 'image'),
					'read-only' => false,
					'subtitle' => esc_html__('Upload background image for header.', 'knost'),
				),

				// --------main header Background options end----------//

				// --------main header Menu options start----------//
				array(
					'id' => 'menu_color',
					'type' => 'button_set',
					'title' => esc_html__('Menu Color Options', 'knost'),
					'subtitle' => esc_html__('Select Menu color .', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost'),
					),
					'default' => esc_html__('default', 'knost')
				),
				array(
					'id' => 'header_menu_color',
					'type' => 'color',
					'required' => array('menu_color', '=', 'custom'),
					'desc' => esc_html__('Menu Color', 'knost'),
					'mode' => 'background',
					'transparent' => false
				),


				array(
					'id' => 'hover_menu_color',
					'type' => 'color',
					'required' => array('menu_color', '=', 'custom'),
					'desc' => esc_html__('Menu Hover Color', 'knost'),
					'mode' => 'background',
					'transparent' => false
				),

				//----sub menu options start---//
				array(
					'id' => 'header_submenu_color_type',
					'type' => 'button_set',
					'title' => esc_html__('Submenu Color Options', 'knost'),
					'subtitle' => esc_html__('Select submenu color.', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost'),
					),
					'default' => esc_html__('default', 'knost')
				),

				array(
					'id' => 'submenu_color',
					'type' => 'color',
					'desc' => esc_html__('Submenu Color', 'knost'),
					'required' => array('header_submenu_color_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),


				array(
					'id' => 'hover_submenu_color',
					'type' => 'color',
					'desc' => esc_html__('Submenu Hover Color', 'knost'),
					'required' => array('header_submenu_color_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'submenu_background_color',
					'type' => 'color',
					'desc' => esc_html__('Submenu Background Color', 'knost'),
					'required' => array('header_submenu_color_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'hover_submenu_bg_color',
					'type' => 'color',
					'desc' => esc_html__('Submenu Background Hover Color', 'knost'),
					'required' => array('header_submenu_color_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),
				//----sub menu options end----//


				// --------main header Menu options end----------//

				// --------main header responsive Menu Button Options start----------//
				array(
					'id' => 'burger_menu_button_type',
					'type' => 'button_set',
					'title' => esc_html__('Burger Menu', 'knost'),
					'subtitle' => esc_html__('Select color for burger Menu', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost')
					),
					'default' => 'default'
				),

				array(
					'id' => 'burger_menu_icon',
					'type' => 'color',
					'desc' => esc_html__('Toggle Icon color', 'knost'),
					'required' => array('burger_menu_button_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'burger_menu_popup_bg',
					'type' => 'color',
					'desc' => esc_html__('Model Background color', 'knost'),
					'required' => array('burger_menu_button_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'burger_menu_color',
					'type' => 'color',
					'desc' => esc_html__('Menu color', 'knost'),
					'required' => array('burger_menu_button_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'burger_hover_menu_color',
					'type' => 'color',
					'desc' => esc_html__('Menu hover color', 'knost'),
					'required' => array('burger_menu_button_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'burger_submenu_color',
					'type' => 'color',
					'desc' => esc_html__('Sub Menu Color', 'knost'),
					'required' => array('burger_menu_button_type', '=', 'custom'),
					'mode' => 'background',
					'transparent' => false
				),


				// --------main header responsive Menu Button Options end----------//

				// --------main header Search Options start----------//
				array(
					'id' => 'header_display_button',
					'type' => 'button_set',
					'title' => esc_html__('Display Search Icon', 'knost'),
					'subtitle' => esc_html__('Turn on to display the Search in header.', 'knost'),
					'options' => array(
						'yes' => esc_html__('On', 'knost'),
						'no' => esc_html__('Off', 'knost')
					),
					'default' => esc_html__('yes', 'knost')
				),

				array(
					'id' => 'header_search_text',
					'type' => 'text',
					'title' => esc_html__('Search Text', 'knost'),
					'required' => array('header_display_button', '=', 'yes'),
					'validate' => 'text',
					'default' => esc_html__('Search', 'knost'),
					'subtitle' => esc_html__('Enter Header Search Text .', 'knost'),
				),

				array(
					'id' => 'button_color',
					'type' => 'button_set',
					'required' => array('header_display_button', '=', 'yes'),
					'title' => esc_html__('Search Icon', 'knost'),
					'subtitle' => esc_html__('Turn on to display the Search color in header.', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost')
					),
					'default' => esc_html__('default', 'knost')
				),

				array(
					'id' => 'button_bg_color',
					'type' => 'color',
					'desc' => esc_html__('Icon color', 'knost'),
					'required' => array('button_color', '=', 'custom'),
					'desc' => esc_html__('Select for button color options.', 'knost'),
					'mode' => 'background',
					'transparent' => false
				),

				// --------main header Search Options end----------//
			)
		));

		//-----Sticky Header Options Start---//
		Redux::set_section($this->opt_name, array(
			'title' => esc_html__('Sticky Header', 'knost'),
			'id' => 'knost_sticky-header-variation',
			'subsection' => true,
			'desc' => esc_html__('This section contains options for sticky header menu and background color.', 'knost'),
			'fields' => array(

				array(
					'id' => 'display_sticky_header',
					'type' => 'button_set',
					'title' => esc_html__('Sticky Header', 'knost'),
					'subtitle' => esc_html__('Turn on to display sticky header.', 'knost'),
					'options' => array(
						'yes' => esc_html__('On', 'knost'),
						'no' => esc_html__('Off', 'knost')
					),
					'default' => esc_html__('yes', 'knost')
				),
				// --------sticky header background options start----------//
				array(
					'id' => 'sticky_header_bg',
					'type' => 'button_set',
					'required' => array('display_sticky_header', '=', 'yes'),
					'title' => esc_html__('Background', 'knost'),
					'subtitle' => esc_html__('Select the variation for sticky header background', 'knost'),
					'options' => array(
						'default' => esc_html__('Default', 'knost'),
						'color' => esc_html__('Color', 'knost'),
						'image' => esc_html__('Image', 'knost'),
						'transparent' => esc_html__('Transparent', 'knost')
					),
					'default' => esc_html__('default', 'knost')
				),

				array(
					'id' => 'sticky_header_bg_color',
					'type' => 'color',
					'desc' => esc_html__('Set Background Color', 'knost'),
					'required' => array('sticky_header_bg', '=', 'color'),
					'mode' => 'background',
					'transparent' => false
				),

				array(
					'id' => 'sticky_header_bg_img',
					'type' => 'media',
					'url' => false,
					'desc' => esc_html__('Upload Image', 'knost'),
					'required' => array('sticky_header_bg', '=', 'image'),
					'read-only' => false,
					'subtitle' => esc_html__('Upload background image for sticky header.', 'knost'),
				),
				// --------sticky header Background options end----------//
				// --------sticky header Menu options start----------//

				array(
					'id'        => 'sticky_menu_color_type',
					'type'      => 'button_set',
					'required'  => array('display_sticky_header', '=', 'yes'),
					'title'     => esc_html__('Menu Color Options', 'knost'),
					'subtitle' => esc_html__('Select Menu color for sticky.', 'knost'),
					'options'   => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost'),
					),
					'default'   => esc_html__('default', 'knost')
				),
				array(
					'id'            => 'sticky_menu_color',
					'type'          => 'color',
					'required'  => array('sticky_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Menu color', 'knost'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_menu_hover_color',
					'type'          => 'color',
					'required'  => array('sticky_menu_color_type', '=', 'custom'),
					'desc'     => esc_html__('Menu hover color', 'knost'),
					'mode'          => 'background',
					'transparent'   => false
				),

				//----sticky sub menu options start---//
				array(
					'id'        => 'sticky_header_submenu_color_type',
					'type'      => 'button_set',
					'title'     => esc_html__('Submenu Color Options', 'knost'),
					'subtitle' => esc_html__('Select submenu color for sticky.', 'knost'),
					'required'  => array('display_sticky_header', '=', 'yes'),
					'options'   => array(
						'default' => esc_html__('Default', 'knost'),
						'custom' => esc_html__('Custom', 'knost'),
					),
					'default'   => esc_html__('default', 'knost')
				),

				array(
					'id'            => 'sticky_knost_header_submenu_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Color', 'knost'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),


				array(
					'id'            => 'sticky_knost_header_submenu_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Hover Color', 'knost'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_knost_header_submenu_background_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Background Color', 'knost'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),

				array(
					'id'            => 'sticky_header_submenu_background_hover_color',
					'type'          => 'color',
					'desc'     => esc_html__('Submenu Background Hover Color', 'knost'),
					'required'  => array('sticky_header_submenu_color_type', '=', 'custom'),
					'mode'          => 'background',
					'transparent'   => false
				),
				// --------sticky header Menu options start----------//sss
			)
		));
	}
}
